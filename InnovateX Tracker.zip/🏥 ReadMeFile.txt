🏥 MedNest - Remote Patient Monitoring & Telemedicine System
MedNest is a cutting-edge platform that seamlessly integrates IoT devices, a web portal, and a mobile application to enable Remote Patient Monitoring (RPM) and Telemedicine. It ensures real-time data collection, intelligent alerts, and easy communication between patients and doctors.

📚 Table of Contents
✨ Features

📡 System Overview

⚙ Tech Stack

🚀 Setup Instructions

📊 Data Flow Architecture

📱 Mobile App Overview

🌐 Website Overview

🔗 Demo Video

🤝 Contributors

✨ Features
✅ Real-time health monitoring using IoT devices
✅ AI-driven health insights and threshold-based alerts
✅ Seamless doctor consultation and appointment booking
✅ HIPAA/GDPR-compliant data security
✅ Integrated chatbot powered by ChatGPT-4.0
✅ Emergency SOS features for critical situations

📡 System Overview
MedNest comprises three main components:

1. ESP32 Hardware Setup
Simulated using Wokwi with various health sensors:

Temperature, SpO₂, ECG, Heart Rate, Blood Pressure, Fall Detection, Gyroscope, and Respiration Rate.

Potentiometers simulate data where hardware is unavailable.

Data is transmitted in real-time to a Firebase Realtime Database.

2. Mobile App (Prototype)
Home Page: Overview of MedNest features

Sign-Up/Login: User authentication

Devices Page: Overview of supported RPM devices

Dashboard: Real-time vitals and AI-driven alerts

Doctor Consultation & Booking: Search, select, and schedule consultations

Doctor Prescription: Digital prescriptions with health instructions

Emergency SOS Features: Quick response tools for critical situations

3. Website Platform
Home Page: Overview of MedNest’s offerings

Monitoring Page: Displays real-time sensor data from ESP32

Statistics Page: Visual representation of historical data (line, bar, pie graphs)

Appointment Page: Schedule appointments with doctors based on availability

AI Chatbot: Instant health-related assistance powered by ChatGPT-4.0

User Profile Page: Displays user profile image and information

⚙ Tech Stack
🎯 Hardware & Simulation:
ESP32 simulated using Wokwi

Potentiometers as alternate sensors for data simulation

🗄 Backend:
Firebase Realtime Database for data storage

Twilio API for WhatsApp notifications and emergency alerts

🐍 Python Scripts:
datasend.py – Simulates and sends human-like data to Firebase

fetch_live_data.py – Fetches real-time data from Firebase

firebaseadmininit.py – Initializes Firebase connection

threshold_checker.py – Monitors vitals and triggers alerts

message_sender.py – Sends alerts using Twilio

main.py – Executes all processes simultaneously

🌐 Website:
HTML and CSS for frontend

Python for fetching and interacting with Firebase

🚀 Setup Instructions
Follow these steps to run MedNest successfully:

📡 ESP32 Simulation Setup
Open Wokwi and load the ESP32 code.

Run the simulation to start sending sensor data to Firebase.

🐍 Backend Setup
Clone this repository:

bash
Copy
Edit
git clone https://github.com/your-username/mednest.git
cd mednest
Install required Python libraries:

bash
Copy
Edit
pip install firebase-admin twilio
Run the main Python script:

bash
Copy
Edit
python main.py
🌐 Website Setup
Navigate to the website directory:

bash
Copy
Edit
cd website
Open index.html in your browser to view the website.

📊 Data Flow Architecture
mermaid
Copy
Edit
graph TD
    ESP32 -->|Simulated Data| Firebase
    Firebase -->|Fetch Data| Backend(Python)
    Backend -->|Update| Website
    Backend -->|Alerts| Twilio
    Website -->|User Interaction| Firebase
📱 Mobile App Overview
Prototype created with Figma.

Covers key functionality like real-time monitoring, doctor consultation, and emergency alerts.

🌐 Website Overview
Built with HTML/CSS and integrated with Firebase via Python scripts.

Provides real-time monitoring, statistical insights, AI chatbot assistance, and appointment booking.

🎥 Demo Video
Watch Demo

🤝 Contributors
🧠 Sejal Mishra – Lead Developer & System Architect
                   Mobile App Prototype & Design


💡 Akshat Singh – Frontend & Website Development
                   Python Backend & Firebase Integration

✅ MedNest – Bringing Smart Healthcare Closer to You! 🏥✨